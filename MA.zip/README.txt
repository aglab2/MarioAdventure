Hi! You are playing hack called Mario Adventure, sequel to Mario Heroes 64! Levels were taken from Sonic Adventure directly, some of them from models-resources.com for other games and just random models by aglab2. Made playable by aglab2

This is full hack, it has 130 Stars, any% is 50 Stars. As original Mario Heroes, most of stars are really easy but closer to end difficulty is around 3/5. Inside each course, stars are placed in difficulty order too.

PLEASE TAKE 1 MINUTE OF YOUR TIME AND READ SIGNS AT START OF GAME

Version 1.3:
Added noteblock in c4 tower because I am bad
Fixed couple textboxes

Version 1.2.4:
Added even more help for ex ending warp

Version 1.2.3:
Fixed act specific secrets in c9

Version 1.2.2:
Fixed c2 red block being too high
Fixed warp holes in c4

Version 1.2.1:
Attempt to fix lag, added optimized collision routine

Version 1.2:
Fixed impossible stars

Version 1.1:
Bunch of nerfes everywhere

Version 1.0.3:
Fixed c10 star 7, nerfed star 6
Fixed Mystic Woods star
Nerfed c7s7

Version 1.0.2:
Fixed warp to s6 in Extra Course
MIPS nerf

Version 1.0.1:
Fixed boxes in c9
Fixed death floor issue in OW2-1
Make ending star troll

Version 1.0:
Initial Release